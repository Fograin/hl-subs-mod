Source code from version:
http://www.moddb.com/mods/half-life-subtitles-mod/downloads/new-subtitles-mod-30-full-version-baseeng