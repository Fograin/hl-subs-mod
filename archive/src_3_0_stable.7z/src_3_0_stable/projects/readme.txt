Directory Contents
==================

vs2010
  Contains Visual C++ 2010 Express project and solution files.
  Please read readme.txt included in that folder for further instructions.


Other notes
===========

MSVC++ 6.0 .dsp files can be found in the appropriate folders.

Linux Makefiles can be found in ../linux/
