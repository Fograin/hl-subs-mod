Directory Contents
==================

subs_mod_libs.sln
  Solution file for Visual C++ 2010 Express, containing the main projects for
  compiling subtitles mod DLL files.

subs_mod_utils.sln
  Solution file containing projects for utilities (currently there's only one
  makevfont utility).
