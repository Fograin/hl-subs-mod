//========= Copyright � 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

#if !defined( WRECTH )
#define WRECTH

typedef struct rect_s
{
	int				left, right, top, bottom;
} wrect_t;

#endif