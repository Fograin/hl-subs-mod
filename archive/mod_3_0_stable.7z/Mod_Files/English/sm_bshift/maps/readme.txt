Half-life 1 won't load Blue Shift maps.
To make this to work;
1. You need to copy all maps (all .bsp files) from "bshift/maps" directory and paste them in this directory "sm_bshift/maps"
2. You need to run "convert_maps" .bat file.