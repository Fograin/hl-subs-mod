This directory contains all required English files that needs to be translated.
Purpose: Template for new translations.